"""Backgrounds that are several native shapes rather than one fill.

PowerPoint has no conic gradient and one fill per shape, but a conic gradient is a fan of coloured
wedges and a stack of background layers is a stack of shapes. Both are exact, editable and need no
raster. Wedges are clipped to the element's box (rounded corners included) so nothing spills out.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from itertools import pairwise

from domoxml.core.ir.lowering import mix_colors
from domoxml.core.ir.model import Rgba
from domoxml.core.ir.parse import parse_color, parse_gradient, split_top_level

type Polygon = list[tuple[float, float]]

_CONIC = re.compile(r"^\s*conic-gradient\s*\((.*)\)\s*$", re.IGNORECASE | re.DOTALL)
_FROM = re.compile(r"from\s+(-?[\d.]+)\s*(deg|turn|rad|grad)?", re.IGNORECASE)
_AT = re.compile(r"at\s+(-?[\d.]+)(%|px)\s+(-?[\d.]+)(%|px)", re.IGNORECASE)
_STOP_POSITION = re.compile(r"\s+(-?[\d.]+)(%|deg|turn)\s*$", re.IGNORECASE)
# A uniform 3 degree fan plus wedges at every stop reads as smooth; stops land on exact edges.
_STEP_DEGREES = 3.0
_OVERLAP_DEGREES = 0.25
_CORNER_SEGMENTS = 8


@dataclass(frozen=True)
class Conic:
    """A parsed conic gradient: start angle, centre as box fractions, and stops in degrees."""

    start_deg: float
    center: tuple[float, float]
    stops: tuple[tuple[float, Rgba], ...]


@dataclass(frozen=True)
class Wedge:
    """One coloured sector of a conic gradient, as a polygon in box coordinates (px)."""

    points: tuple[tuple[float, float], ...]
    color: Rgba


def stacked_gradients(value: str | None) -> list[str] | None:
    """The layers of a stacked gradient background, top first, or ``None`` if not all gradients."""
    if not value or value.strip().lower() == "none":
        return None
    layers = [layer.strip() for layer in split_top_level(value)]
    if len(layers) < 2 or any(parse_gradient(layer) is None for layer in layers):
        return None
    return layers


def parse_conic(value: str | None, *, width_px: float, height_px: float) -> Conic | None:
    """Parse one ``conic-gradient``; ``None`` for stacked layers or anything not understood."""
    if not value:
        return None
    match = _CONIC.match(value)
    if match is None or len(split_top_level(value)) > 1:
        return None
    parts = [part.strip() for part in split_top_level(match.group(1))]
    start, center = 0.0, (0.5, 0.5)
    if parts and not _has_color(parts[0]):
        prelude, parts = parts[0], parts[1:]
        from_match = _FROM.search(prelude)
        if from_match is not None:
            factor = {"": 1.0, "deg": 1.0, "turn": 360.0, "rad": 180 / math.pi, "grad": 0.9}
            start = float(from_match.group(1)) * factor[(from_match.group(2) or "").lower()]
        at_match = _AT.search(prelude)
        if at_match is not None:
            x, x_unit, y, y_unit = at_match.groups()
            center = (
                float(x) / 100 if x_unit == "%" else float(x) / width_px,
                float(y) / 100 if y_unit == "%" else float(y) / height_px,
            )
    raw: list[tuple[Rgba, float | None]] = []
    for part in parts:
        position = _STOP_POSITION.search(part)
        color = parse_color(part[: position.start()] if position else part)
        if color is None:
            return None
        angle = None
        if position is not None:
            amount, unit = float(position.group(1)), position.group(2).lower()
            angle = amount * 3.6 if unit == "%" else amount * 360 if unit == "turn" else amount
        raw.append((color, angle))
    resolved = _resolve_angles(raw)
    return Conic(start, center, tuple(resolved)) if resolved is not None else None


def _has_color(part: str) -> bool:
    return parse_color(_STOP_POSITION.sub("", part)) is not None


def _resolve_angles(raw: list[tuple[Rgba, float | None]]) -> list[tuple[float, Rgba]] | None:
    """CSS stop defaults: the first is 0, the last 360, the rest spread evenly; never backwards."""
    if len(raw) < 2:
        return None
    angles: list[float | None] = [angle for _, angle in raw]
    angles[0] = 0.0 if angles[0] is None else angles[0]
    angles[-1] = 360.0 if angles[-1] is None else angles[-1]
    index = 1
    while index < len(angles):
        if angles[index] is None:
            end = next(j for j in range(index, len(angles)) if angles[j] is not None)
            low, high = angles[index - 1] or 0.0, angles[end] or 0.0
            for step in range(index, end):
                angles[step] = low + (high - low) * (step - index + 1) / (end - index + 1)
            index = end
        index += 1
    ordered: list[tuple[float, Rgba]] = []
    floor = -math.inf
    for (color, _), angle in zip(raw, angles, strict=True):
        floor = max(floor, angle or 0.0)
        ordered.append((floor, color))
    return ordered


def color_at(conic: Conic, angle: float) -> Rgba:
    """The gradient's colour ``angle`` degrees round from its start, in premultiplied alpha."""
    stops = conic.stops
    if angle <= stops[0][0]:
        return stops[0][1]
    for (a0, c0), (a1, c1) in pairwise(stops):
        if a0 <= angle <= a1:
            return c1 if a1 <= a0 else mix_colors(c0, c1, (angle - a0) / (a1 - a0))
    return stops[-1][1]


def conic_wedges(
    conic: Conic, *, width_px: float, height_px: float, radius_px: float = 0.0
) -> list[Wedge]:
    """Cut ``conic`` into wedges, each clipped to the (rounded) box."""
    window = rounded_box(width_px, height_px, radius_px)
    center = (conic.center[0] * width_px, conic.center[1] * height_px)
    reach = 2.0 * (width_px + height_px)
    boundaries = {0.0, 360.0}
    boundaries.update(a for a, _ in conic.stops if 0.0 <= a <= 360.0)
    boundaries.update(float(step) for step in range(0, 360, int(_STEP_DEGREES)))
    edges = sorted(boundaries)
    wedges: list[Wedge] = []
    for index, (a0, a1) in enumerate(pairwise(edges)):
        if a1 - a0 < 1e-6:
            continue
        lead = a0 - (_OVERLAP_DEGREES if index else 0.0)
        triangle = [
            center,
            _ray(center, conic.start_deg + lead, reach),
            _ray(center, conic.start_deg + a1, reach),
        ]
        polygon = clip_polygon(triangle, window)
        if len(polygon) >= 3:
            wedges.append(Wedge(tuple(polygon), color_at(conic, (a0 + a1) / 2)))
    return wedges


@dataclass(frozen=True)
class Radial:
    """A parsed radial gradient: centre as box fractions, circle or ellipse, stops as fractions."""

    center: tuple[float, float]
    circle: bool
    extent: str
    stops: tuple[tuple[float, Rgba], ...]


_RADIAL = re.compile(r"^\s*radial-gradient\s*\((.*)\)\s*$", re.IGNORECASE | re.DOTALL)
_EXTENTS = ("closest-side", "farthest-side", "closest-corner", "farthest-corner")
_FRACTION = re.compile(r"\s+(-?[\d.]+)%\s*$")


def parse_radial(value: str | None, *, width_px: float, height_px: float) -> Radial | None:
    """Parse one ``radial-gradient`` with percentage stops; ``None`` for anything else."""
    if not value:
        return None
    match = _RADIAL.match(value)
    if match is None or len(split_top_level(value)) > 1:
        return None
    parts = [part.strip() for part in split_top_level(match.group(1))]
    circle, extent, center = False, "farthest-corner", (0.5, 0.5)
    if parts and not _has_fraction_color(parts[0]):
        prelude = parts.pop(0).lower()
        circle = "circle" in prelude
        extent = next((word for word in _EXTENTS if word in prelude), extent)
        at = _AT.search(prelude)
        if at is not None:
            x, x_unit, y, y_unit = at.groups()
            center = (
                float(x) / 100 if x_unit == "%" else float(x) / width_px,
                float(y) / 100 if y_unit == "%" else float(y) / height_px,
            )
        remainder = _AT.sub("", prelude).replace("circle", "").replace("ellipse", "")
        if any(word in remainder for word in _EXTENTS):
            remainder = re.sub("|".join(_EXTENTS), "", remainder)
        if remainder.strip():
            return None
    raw: list[tuple[Rgba, float | None]] = []
    for part in parts:
        position = _FRACTION.search(part)
        color = parse_color(part[: position.start()] if position else part)
        if color is None or (position is None and re.search(r"\d(px|em|deg)\s*$", part)):
            return None
        raw.append((color, float(position.group(1)) / 100 if position else None))
    fractions = _resolve_angles([(c, None if a is None else a * 360.0) for c, a in raw])
    if fractions is None:
        return None
    if any(color.a < 1.0 for _, color in fractions):
        return None  # stacked bands would compound the alpha; only opaque stops are exact
    return Radial(center, circle, extent, tuple((a / 360.0, c) for a, c in fractions))


def _has_fraction_color(part: str) -> bool:
    return parse_color(_FRACTION.sub("", part)) is not None


def radial_bands(
    radial: Radial, *, width_px: float, height_px: float, radius_px: float = 0.0, bands: int = 48
) -> list[Wedge]:
    """Concentric ellipse bands, outermost first, each clipped to the (rounded) box.

    Painted in order, every band is the gradient's colour over its own ring, so the result matches
    the browser's centre, aspect ratio and stops without any native radial gradient.
    """
    cx, cy = radial.center[0] * width_px, radial.center[1] * height_px
    rx, ry = _radii(radial, cx, cy, width_px, height_px)
    window = rounded_box(width_px, height_px, radius_px)
    edges = sorted(
        {
            0.0,
            1.0,
            *(f for f, _ in radial.stops if 0.0 < f < 1.0),
            *(i / bands for i in range(1, bands)),
        }
    )
    stops = tuple((fraction * 360.0, color) for fraction, color in radial.stops)
    conic = Conic(0.0, (0.5, 0.5), stops)
    # Past the ending ellipse CSS keeps painting the last stop, so start from the whole box.
    facets: list[Wedge] = [Wedge(tuple(window), radial.stops[-1][1])]
    for inner, outer in reversed(list(pairwise(edges))):
        outline = [
            (
                cx + rx * outer * math.cos(math.radians(a)),
                cy + ry * outer * math.sin(math.radians(a)),
            )
            for a in range(0, 360, 5)
        ]
        polygon = clip_polygon(outline, window)
        if len(polygon) >= 3:
            facets.append(Wedge(tuple(polygon), color_at(conic, (inner + outer) / 2 * 360.0)))
    return facets


def _radii(
    radial: Radial, cx: float, cy: float, width: float, height: float
) -> tuple[float, float]:
    """The ellipse's (or circle's) radii for the gradient's extent keyword."""
    near_x, near_y = min(cx, width - cx), min(cy, height - cy)
    far_x, far_y = max(cx, width - cx), max(cy, height - cy)
    if radial.circle:
        side = {
            "closest-side": min(near_x, near_y),
            "farthest-side": max(far_x, far_y),
            "closest-corner": math.hypot(near_x, near_y),
            "farthest-corner": math.hypot(far_x, far_y),
        }[radial.extent]
        return side, side
    if radial.extent == "closest-side":
        return near_x, near_y
    if radial.extent == "farthest-side":
        return far_x, far_y
    scale = math.sqrt(2.0)
    if radial.extent == "closest-corner":
        return near_x * scale, near_y * scale
    return far_x * scale, far_y * scale


def _ray(origin: tuple[float, float], degrees: float, length: float) -> tuple[float, float]:
    """A point ``length`` from ``origin`` at a CSS angle (0 is up, clockwise)."""
    radians = math.radians(degrees)
    return origin[0] + length * math.sin(radians), origin[1] - length * math.cos(radians)


def rounded_box(width: float, height: float, radius: float) -> Polygon:
    """The box as a clockwise polygon, with each corner rounded by ``radius`` px."""
    r = min(max(radius, 0.0), width / 2, height / 2)
    if r <= 0:
        return [(0.0, 0.0), (width, 0.0), (width, height), (0.0, height)]
    points: Polygon = []
    corners = [
        ((width - r, r), -90.0),
        ((width - r, height - r), 0.0),
        ((r, height - r), 90.0),
        ((r, r), 180.0),
    ]
    for (cx, cy), start in corners:
        for step in range(_CORNER_SEGMENTS + 1):
            angle = math.radians(start + 90.0 * step / _CORNER_SEGMENTS)
            points.append((cx + r * math.cos(angle), cy + r * math.sin(angle)))
    return points


def clip_polygon(subject: Polygon, window: Polygon) -> Polygon:
    """Sutherland-Hodgman: ``subject`` clipped to the convex clockwise ``window``."""
    output: Polygon = list(subject)
    for start, end in zip(window, window[1:] + window[:1], strict=True):
        if not output:
            break
        candidates: Polygon = output
        output = []
        previous = candidates[-1]
        for current in candidates:
            if _inside(current, start, end):
                if not _inside(previous, start, end):
                    output.append(_cross(previous, current, start, end))
                output.append(current)
            elif _inside(previous, start, end):
                output.append(_cross(previous, current, start, end))
            previous = current
    return output


type Point = tuple[float, float]


def _inside(point: Point, start: Point, end: Point) -> bool:
    """Whether ``point`` is on the inner side of the clockwise edge ``start`` -> ``end``."""
    along = (end[0] - start[0], end[1] - start[1])
    return along[0] * (point[1] - start[1]) - along[1] * (point[0] - start[0]) >= 0


def _cross(a: Point, b: Point, c: Point, d: Point) -> Point:
    """Where segment ``a-b`` meets the line ``c-d``."""
    a1, b1 = b[1] - a[1], a[0] - b[0]
    a2, b2 = d[1] - c[1], c[0] - d[0]
    determinant = a1 * b2 - a2 * b1
    if abs(determinant) < 1e-12:
        return b
    c1, c2 = a1 * a[0] + b1 * a[1], a2 * c[0] + b2 * c[1]
    return (b2 * c1 - b1 * c2) / determinant, (a1 * c2 - a2 * c1) / determinant


_CLIP = re.compile(r"^\s*(circle|ellipse|inset)\s*\((.*)\)\s*$", re.IGNORECASE | re.DOTALL)
_CLIP_AT = re.compile(r"\bat\s+(.+)$", re.IGNORECASE)
_CLIP_ROUND = re.compile(r"\bround\s+(.+)$", re.IGNORECASE)
_ELLIPSE_STEPS = 96


def _length(token: str, reference: float) -> float | None:
    """A CSS length or percentage of ``reference`` in px, or ``None``."""
    match = re.fullmatch(r"(-?[\d.]+)(px|%)?", token.strip())
    if match is None:
        return None
    number = float(match.group(1))
    return number / 100.0 * reference if match.group(2) == "%" else number


def _position(text: str | None, width: float, height: float) -> tuple[float, float] | None:
    """The ``at`` position of a basic shape (keywords or lengths), default the centre."""
    if text is None:
        return width / 2, height / 2
    words = {"left": "0%", "top": "0%", "center": "50%", "right": "100%", "bottom": "100%"}
    tokens = [words.get(token.lower(), token) for token in text.split()]
    if len(tokens) == 1:
        tokens = [tokens[0], "50%"]
    if len(tokens) != 2:
        return None
    x, y = _length(tokens[0], width), _length(tokens[1], height)
    if x is None or y is None:
        return None
    # `top left` style keyword pairs come in either order: a vertical keyword first means swap.
    first = text.split()[0].lower()
    if first in ("top", "bottom") and len(text.split()) == 2:
        x, y = _length(tokens[1], width), _length(tokens[0], height)
        if x is None or y is None:
            return None
    return x, y


def ellipse_polygon(cx: float, cy: float, rx: float, ry: float) -> Polygon:
    """A clockwise polygon approximating an ellipse."""
    return [
        (
            cx + rx * math.cos(2 * math.pi * i / _ELLIPSE_STEPS),
            cy + ry * math.sin(2 * math.pi * i / _ELLIPSE_STEPS),
        )
        for i in range(_ELLIPSE_STEPS)
    ]


def parse_clip_shape(value: str | None, *, width_px: float, height_px: float) -> Polygon | None:
    """A ``clip-path`` basic shape (circle, ellipse, inset) as a polygon in box px, else ``None``.

    ``polygon()`` is parsed by :func:`domoxml.core.ir.parse.parse_polygon`.
    """
    match = _CLIP.match(value or "")
    if match is None:
        return None
    kind, body = match.group(1).lower(), match.group(2).strip()
    if kind == "inset":
        return _inset(body, width_px, height_px)
    at = _CLIP_AT.search(body)
    centre = _position(at.group(1) if at else None, width_px, height_px)
    radii = (body[: at.start()] if at else body).split()
    if centre is None:
        return None
    reference = math.sqrt((width_px**2 + height_px**2) / 2)
    near_x, near_y = min(centre[0], width_px - centre[0]), min(centre[1], height_px - centre[1])
    far_x, far_y = max(centre[0], width_px - centre[0]), max(centre[1], height_px - centre[1])
    if kind == "circle":
        if len(radii) > 1:
            return None
        word = radii[0].lower() if radii else "closest-side"
        radius = {
            "closest-side": min(near_x, near_y),
            "farthest-side": max(far_x, far_y),
        }.get(word)
        if radius is None:
            radius = _length(word, reference)
        return None if radius is None else ellipse_polygon(*centre, radius, radius)
    if len(radii) not in (0, 2):
        return None
    sides = {
        "closest-side": (near_x, near_y),
        "farthest-side": (far_x, far_y),
    }
    if not radii:
        rx, ry = sides["closest-side"]
    elif radii[0].lower() in sides and radii[1].lower() in sides:
        rx, ry = sides[radii[0].lower()][0], sides[radii[1].lower()][1]
    else:
        horizontal, vertical = _length(radii[0], width_px), _length(radii[1], height_px)
        if horizontal is None or vertical is None:
            return None
        rx, ry = horizontal, vertical
    return ellipse_polygon(*centre, rx, ry)


def _inset(body: str, width: float, height: float) -> Polygon | None:
    round_match = _CLIP_ROUND.search(body)
    sides = (body[: round_match.start()] if round_match else body).split()
    if not 1 <= len(sides) <= 4:
        return None
    pattern = {1: (0, 0, 0, 0), 2: (0, 1, 0, 1), 3: (0, 1, 2, 1), 4: (0, 1, 2, 3)}[len(sides)]
    top, right, bottom, left = (sides[index] for index in pattern)
    insets = (
        _length(top, height),
        _length(right, width),
        _length(bottom, height),
        _length(left, width),
    )
    if any(value is None for value in insets):
        return None
    above, beside_right, below, beside_left = (float(v) for v in insets if v is not None)
    inner_w = width - beside_left - beside_right
    inner_h = height - above - below
    if inner_w <= 0 or inner_h <= 0:
        return []
    radius = 0.0
    if round_match:
        values = [_length(part, min(inner_w, inner_h)) for part in round_match.group(1).split()]
        if any(value is None for value in values) or len(set(values)) != 1:
            return None  # per-corner radii differ: not one rounded box
        radius = float(values[0] or 0.0)
    return [(x + beside_left, y + above) for x, y in rounded_box(inner_w, inner_h, radius)]


type Corner = tuple[float, float]
_KAPPA = 0.5522847498


def corner_radii(
    styles: dict[str, str], *, width_px: float, height_px: float
) -> tuple[Corner, Corner, Corner, Corner] | None:
    """The four ``(horizontal, vertical)`` corner radii in px (TL, TR, BR, BL), or ``None``.

    Read from the computed longhands, scaled down together when neighbours would overlap, as CSS
    requires.
    """
    corners: list[Corner] = []
    for key in (
        "borderTopLeftRadius",
        "borderTopRightRadius",
        "borderBottomRightRadius",
        "borderBottomLeftRadius",
    ):
        tokens = (styles.get(key) or "0px").split()
        if not 1 <= len(tokens) <= 2:
            return None
        horizontal = _length(tokens[0], width_px)
        vertical = _length(tokens[-1], height_px)
        if horizontal is None or vertical is None:
            return None
        corners.append((max(0.0, horizontal), max(0.0, vertical)))
    top_left, top_right, bottom_right, bottom_left = corners
    sums = (
        (width_px, top_left[0] + top_right[0]),
        (width_px, bottom_left[0] + bottom_right[0]),
        (height_px, top_left[1] + bottom_left[1]),
        (height_px, top_right[1] + bottom_right[1]),
    )
    scale = min([1.0] + [side / total for side, total in sums if total > side > 0])
    scaled = [(x * scale, y * scale) for x, y in corners]
    return scaled[0], scaled[1], scaled[2], scaled[3]


def is_plain_round_rect(radii: tuple[Corner, Corner, Corner, Corner]) -> bool:
    """Whether every corner is the same circle, which a preset ``roundRect`` already is."""
    first = radii[0]
    return all(corner == first for corner in radii) and abs(first[0] - first[1]) < 1e-6


def rounded_path(
    width: float, height: float, radii: tuple[Corner, Corner, Corner, Corner]
) -> list[tuple[str, list[tuple[float, float]]]]:
    """A box with elliptical corners as ``("M"|"L"|"C", points)`` commands, clockwise from TL."""
    (tl_x, tl_y), (tr_x, tr_y), (br_x, br_y), (bl_x, bl_y) = radii
    k = _KAPPA
    return [
        ("M", [(tl_x, 0.0)]),
        ("L", [(width - tr_x, 0.0)]),
        ("C", [(width - tr_x + tr_x * k, 0.0), (width, tr_y - tr_y * k), (width, tr_y)]),
        ("L", [(width, height - br_y)]),
        (
            "C",
            [
                (width, height - br_y + br_y * k),
                (width - br_x + br_x * k, height),
                (width - br_x, height),
            ],
        ),
        ("L", [(bl_x, height)]),
        ("C", [(bl_x - bl_x * k, height), (0.0, height - bl_y + bl_y * k), (0.0, height - bl_y)]),
        ("L", [(0.0, tl_y)]),
        ("C", [(0.0, tl_y - tl_y * k), (tl_x - tl_x * k, 0.0), (tl_x, 0.0)]),
    ]
